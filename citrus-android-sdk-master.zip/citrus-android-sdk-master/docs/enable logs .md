<b> How to enable Logs? </b>

      citrusClient.enableLog(true); // (Make sure you are enabling logs before citrusClient.init() method.)

   1. Logs can be used while debugging any issue.
   2. Logs are disabled by default.
   3. Make sure you are turning off the logs when you are using Production Environment. 
   


