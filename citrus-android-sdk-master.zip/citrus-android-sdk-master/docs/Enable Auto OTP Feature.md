####How to enable Auto OTP feature?

      citrusClient.enableAutoOtpReading(true); 

       1. Toggle above method with true/false value to enable/disable the Auto OTP feature.
    

